package net.mcreator.chickennuggetacsnonconformist.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.chickennuggetacsnonconformist.entity.LightCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.client.model.ModelFireCircle;

public class LightCircleRenderer extends MobRenderer<LightCircleEntity, ModelFireCircle<LightCircleEntity>> {
	public LightCircleRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelFireCircle(context.bakeLayer(ModelFireCircle.LAYER_LOCATION)), 0.5f);
		this.addLayer(new EyesLayer<LightCircleEntity, ModelFireCircle<LightCircleEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("chickennuggetacs_nonconformist:textures/roar.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(LightCircleEntity entity) {
		return new ResourceLocation("chickennuggetacs_nonconformist:textures/invis.png");
	}
}
