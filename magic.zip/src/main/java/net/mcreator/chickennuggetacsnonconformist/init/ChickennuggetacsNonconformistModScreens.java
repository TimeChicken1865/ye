
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chickennuggetacsnonconformist.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.chickennuggetacsnonconformist.client.gui.WManipulation1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.W1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.UpgradesScreen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.SManipulation1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.S1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.RaceGUIScreen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.MagicScreen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.MagicAttack1GUIScreen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.LManipulation1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.LAManipulation1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.LA1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.L1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.HumanScreen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.GuildOwnerGUIHitScreen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.GuildGUIScreen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.FManipulation1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.F1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.EManipulation1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.E1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.DManipulation1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.DAManipulation1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.DA1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.D1Screen;
import net.mcreator.chickennuggetacsnonconformist.client.gui.ConfirmimmuntiyresetScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ChickennuggetacsNonconformistModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.MAGIC, MagicScreen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.MAGIC_ATTACK_1_GUI, MagicAttack1GUIScreen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.L_1, L1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.L_MANIPULATION_1, LManipulation1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.UPGRADES, UpgradesScreen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.RACE_GUI, RaceGUIScreen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.HUMAN, HumanScreen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.F_1, F1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.F_MANIPULATION_1, FManipulation1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.W_1, W1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.W_MANIPULATION_1, WManipulation1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.D_1, D1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.D_MANIPULATION_1, DManipulation1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.E_1, E1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.E_MANIPULATION_1, EManipulation1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.DA_1, DA1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.DA_MANIPULATION_1, DAManipulation1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.GUILD_OWNER_GUI_HIT, GuildOwnerGUIHitScreen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.GUILD_GUI, GuildGUIScreen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.CONFIRMIMMUNTIYRESET, ConfirmimmuntiyresetScreen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.LA_1, LA1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.LA_MANIPULATION_1, LAManipulation1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.S_1, S1Screen::new);
			MenuScreens.register(ChickennuggetacsNonconformistModMenus.S_MANIPULATION_1, SManipulation1Screen::new);
		});
	}
}
