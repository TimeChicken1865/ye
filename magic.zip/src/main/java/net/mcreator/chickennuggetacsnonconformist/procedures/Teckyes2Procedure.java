package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;

public class Teckyes2Procedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = entity.getYRot();
			entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.immunity12 = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		{
			double _setval = entity.getYRot();
			entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.immunity = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		{
			double _setval = 1;
			entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.Guild_Rank = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		if (entity instanceof Player _player)
			_player.closeContainer();
	}
}
