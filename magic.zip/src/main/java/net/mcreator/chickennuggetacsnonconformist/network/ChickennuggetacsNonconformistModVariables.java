package net.mcreator.chickennuggetacsnonconformist.network;

import net.minecraftforge.fmllegacy.network.PacketDistributor;
import net.minecraftforge.fmllegacy.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.AttachCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.common.util.FakePlayer;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.CapabilityToken;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.Capability;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.nbt.Tag;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.Direction;
import net.minecraft.client.Minecraft;

import net.mcreator.chickennuggetacsnonconformist.ChickennuggetacsNonconformistMod;

import java.util.function.Supplier;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ChickennuggetacsNonconformistModVariables {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		ChickennuggetacsNonconformistMod.addNetworkMessage(PlayerVariablesSyncMessage.class, PlayerVariablesSyncMessage::buffer,
				PlayerVariablesSyncMessage::new, PlayerVariablesSyncMessage::handler);
	}

	@SubscribeEvent
	public static void init(RegisterCapabilitiesEvent event) {
		event.register(PlayerVariables.class);
	}

	@Mod.EventBusSubscriber
	public static class EventBusVariableHandlers {
		@SubscribeEvent
		public static void onPlayerLoggedInSyncPlayerVariables(PlayerEvent.PlayerLoggedInEvent event) {
			if (!event.getPlayer().level.isClientSide())
				((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
						.syncPlayerVariables(event.getPlayer());
		}

		@SubscribeEvent
		public static void onPlayerRespawnedSyncPlayerVariables(PlayerEvent.PlayerRespawnEvent event) {
			if (!event.getPlayer().level.isClientSide())
				((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
						.syncPlayerVariables(event.getPlayer());
		}

		@SubscribeEvent
		public static void onPlayerChangedDimensionSyncPlayerVariables(PlayerEvent.PlayerChangedDimensionEvent event) {
			if (!event.getPlayer().level.isClientSide())
				((PlayerVariables) event.getPlayer().getCapability(PLAYER_VARIABLES_CAPABILITY, null).orElse(new PlayerVariables()))
						.syncPlayerVariables(event.getPlayer());
		}

		@SubscribeEvent
		public static void clonePlayer(PlayerEvent.Clone event) {
			event.getOriginal().revive();
			PlayerVariables original = ((PlayerVariables) event.getOriginal().getCapability(PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new PlayerVariables()));
			PlayerVariables clone = ((PlayerVariables) event.getEntity().getCapability(PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new PlayerVariables()));
			clone.spread = original.spread;
			clone.back = original.back;
			clone.MagicThickness = original.MagicThickness;
			clone.MagicLength = original.MagicLength;
			clone.MagicSpeed = original.MagicSpeed;
			clone.MagicDamage = original.MagicDamage;
			clone.MagicKnowledge = original.MagicKnowledge;
			clone.mana = original.mana;
			clone.MaxMana = original.MaxMana;
			clone.MagicType1 = original.MagicType1;
			clone.CastingOffset = original.CastingOffset;
			clone.trail1 = original.trail1;
			clone.immunity = original.immunity;
			clone.immunity12 = original.immunity12;
			clone.joinedGuild = original.joinedGuild;
			clone.Guild_Rank = original.Guild_Rank;
			if (!event.isWasDeath()) {
			}
		}
	}

	public static final Capability<PlayerVariables> PLAYER_VARIABLES_CAPABILITY = CapabilityManager.get(new CapabilityToken<PlayerVariables>() {
	});

	@Mod.EventBusSubscriber
	private static class PlayerVariablesProvider implements ICapabilitySerializable<Tag> {
		@SubscribeEvent
		public static void onAttachCapabilities(AttachCapabilitiesEvent<Entity> event) {
			if (event.getObject() instanceof Player && !(event.getObject() instanceof FakePlayer))
				event.addCapability(new ResourceLocation("chickennuggetacs_nonconformist", "player_variables"), new PlayerVariablesProvider());
		}

		private final PlayerVariables playerVariables = new PlayerVariables();
		private final LazyOptional<PlayerVariables> instance = LazyOptional.of(() -> playerVariables);

		@Override
		public <T> LazyOptional<T> getCapability(Capability<T> cap, Direction side) {
			return cap == PLAYER_VARIABLES_CAPABILITY ? instance.cast() : LazyOptional.empty();
		}

		@Override
		public Tag serializeNBT() {
			return playerVariables.writeNBT();
		}

		@Override
		public void deserializeNBT(Tag nbt) {
			playerVariables.readNBT(nbt);
		}
	}

	public static class PlayerVariables {
		public double spread = 0;
		public double back = 0;
		public double MagicThickness = 1.0;
		public double MagicLength = 1.0;
		public double MagicSpeed = 1.0;
		public double MagicDamage = 1.0;
		public double MagicKnowledge = 0.1;
		public double mana = 50.0;
		public double MaxMana = 50.0;
		public double MagicType1 = 0;
		public double CastingOffset = 0;
		public boolean trail1 = false;
		public double immunity = 0;
		public double immunity12 = 0;
		public boolean joinedGuild = false;
		public double Guild_Rank = 1.0;

		public void syncPlayerVariables(Entity entity) {
			if (entity instanceof ServerPlayer serverPlayer)
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> serverPlayer),
						new PlayerVariablesSyncMessage(this));
		}

		public Tag writeNBT() {
			CompoundTag nbt = new CompoundTag();
			nbt.putDouble("spread", spread);
			nbt.putDouble("back", back);
			nbt.putDouble("MagicThickness", MagicThickness);
			nbt.putDouble("MagicLength", MagicLength);
			nbt.putDouble("MagicSpeed", MagicSpeed);
			nbt.putDouble("MagicDamage", MagicDamage);
			nbt.putDouble("MagicKnowledge", MagicKnowledge);
			nbt.putDouble("mana", mana);
			nbt.putDouble("MaxMana", MaxMana);
			nbt.putDouble("MagicType1", MagicType1);
			nbt.putDouble("CastingOffset", CastingOffset);
			nbt.putBoolean("trail1", trail1);
			nbt.putDouble("immunity", immunity);
			nbt.putDouble("immunity12", immunity12);
			nbt.putBoolean("joinedGuild", joinedGuild);
			nbt.putDouble("Guild_Rank", Guild_Rank);
			return nbt;
		}

		public void readNBT(Tag Tag) {
			CompoundTag nbt = (CompoundTag) Tag;
			spread = nbt.getDouble("spread");
			back = nbt.getDouble("back");
			MagicThickness = nbt.getDouble("MagicThickness");
			MagicLength = nbt.getDouble("MagicLength");
			MagicSpeed = nbt.getDouble("MagicSpeed");
			MagicDamage = nbt.getDouble("MagicDamage");
			MagicKnowledge = nbt.getDouble("MagicKnowledge");
			mana = nbt.getDouble("mana");
			MaxMana = nbt.getDouble("MaxMana");
			MagicType1 = nbt.getDouble("MagicType1");
			CastingOffset = nbt.getDouble("CastingOffset");
			trail1 = nbt.getBoolean("trail1");
			immunity = nbt.getDouble("immunity");
			immunity12 = nbt.getDouble("immunity12");
			joinedGuild = nbt.getBoolean("joinedGuild");
			Guild_Rank = nbt.getDouble("Guild_Rank");
		}
	}

	public static class PlayerVariablesSyncMessage {
		public PlayerVariables data;

		public PlayerVariablesSyncMessage(FriendlyByteBuf buffer) {
			this.data = new PlayerVariables();
			this.data.readNBT(buffer.readNbt());
		}

		public PlayerVariablesSyncMessage(PlayerVariables data) {
			this.data = data;
		}

		public static void buffer(PlayerVariablesSyncMessage message, FriendlyByteBuf buffer) {
			buffer.writeNbt((CompoundTag) message.data.writeNBT());
		}

		public static void handler(PlayerVariablesSyncMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
			NetworkEvent.Context context = contextSupplier.get();
			context.enqueueWork(() -> {
				if (!context.getDirection().getReceptionSide().isServer()) {
					PlayerVariables variables = ((PlayerVariables) Minecraft.getInstance().player.getCapability(PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new PlayerVariables()));
					variables.spread = message.data.spread;
					variables.back = message.data.back;
					variables.MagicThickness = message.data.MagicThickness;
					variables.MagicLength = message.data.MagicLength;
					variables.MagicSpeed = message.data.MagicSpeed;
					variables.MagicDamage = message.data.MagicDamage;
					variables.MagicKnowledge = message.data.MagicKnowledge;
					variables.mana = message.data.mana;
					variables.MaxMana = message.data.MaxMana;
					variables.MagicType1 = message.data.MagicType1;
					variables.CastingOffset = message.data.CastingOffset;
					variables.trail1 = message.data.trail1;
					variables.immunity = message.data.immunity;
					variables.immunity12 = message.data.immunity12;
					variables.joinedGuild = message.data.joinedGuild;
					variables.Guild_Rank = message.data.Guild_Rank;
				}
			});
			context.setPacketHandled(true);
		}
	}
}
