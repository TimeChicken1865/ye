
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chickennuggetacsnonconformist.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.chickennuggetacsnonconformist.client.model.Modelroar;
import net.mcreator.chickennuggetacsnonconformist.client.model.ModelWindCircle;
import net.mcreator.chickennuggetacsnonconformist.client.model.ModelWaterCircle;
import net.mcreator.chickennuggetacsnonconformist.client.model.ModelThunderCircle;
import net.mcreator.chickennuggetacsnonconformist.client.model.ModelSphere;
import net.mcreator.chickennuggetacsnonconformist.client.model.ModelFireCircle;
import net.mcreator.chickennuggetacsnonconformist.client.model.ModelErathCircle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class ChickennuggetacsNonconformistModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelThunderCircle.LAYER_LOCATION, ModelThunderCircle::createBodyLayer);
		event.registerLayerDefinition(ModelErathCircle.LAYER_LOCATION, ModelErathCircle::createBodyLayer);
		event.registerLayerDefinition(ModelWindCircle.LAYER_LOCATION, ModelWindCircle::createBodyLayer);
		event.registerLayerDefinition(ModelFireCircle.LAYER_LOCATION, ModelFireCircle::createBodyLayer);
		event.registerLayerDefinition(ModelWaterCircle.LAYER_LOCATION, ModelWaterCircle::createBodyLayer);
		event.registerLayerDefinition(ModelSphere.LAYER_LOCATION, ModelSphere::createBodyLayer);
		event.registerLayerDefinition(Modelroar.LAYER_LOCATION, Modelroar::createBodyLayer);
	}
}
