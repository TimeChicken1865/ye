
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chickennuggetacsnonconformist.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.client.event.ParticleFactoryRegisterEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.Minecraft;

import net.mcreator.chickennuggetacsnonconformist.client.particle.SpiritParticleParticle;
import net.mcreator.chickennuggetacsnonconformist.client.particle.ManaParticleParticle;
import net.mcreator.chickennuggetacsnonconformist.client.particle.Lightning1Particle;
import net.mcreator.chickennuggetacsnonconformist.client.particle.LightParticleParticle;
import net.mcreator.chickennuggetacsnonconformist.client.particle.ElectricityParticleParticle;
import net.mcreator.chickennuggetacsnonconformist.client.particle.EarthParticleParticle;

import java.util.function.Function;
import java.util.Map;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ChickennuggetacsNonconformistModParticles {
	private static final Map<ParticleType<?>, Function<SpriteSet, ParticleProvider<SimpleParticleType>>> REGISTRY = new HashMap<>();
	public static final SimpleParticleType LIGHTNING_1 = register(new SimpleParticleType(true).setRegistryName("lightning_1"),
			Lightning1Particle::provider);
	public static final SimpleParticleType ELECTRICITY_PARTICLE = register(new SimpleParticleType(true).setRegistryName("electricity_particle"),
			ElectricityParticleParticle::provider);
	public static final SimpleParticleType EARTH_PARTICLE = register(new SimpleParticleType(false).setRegistryName("earth_particle"),
			EarthParticleParticle::provider);
	public static final SimpleParticleType MANA_PARTICLE = register(new SimpleParticleType(false).setRegistryName("mana_particle"),
			ManaParticleParticle::provider);
	public static final SimpleParticleType LIGHT_PARTICLE = register(new SimpleParticleType(true).setRegistryName("light_particle"),
			LightParticleParticle::provider);
	public static final SimpleParticleType SPIRIT_PARTICLE = register(new SimpleParticleType(true).setRegistryName("spirit_particle"),
			SpiritParticleParticle::provider);

	private static SimpleParticleType register(ParticleType<?> particle, Function<SpriteSet, ParticleProvider<SimpleParticleType>> provider) {
		REGISTRY.put(particle, provider);
		return (SimpleParticleType) particle;
	}

	@SubscribeEvent
	public static void registerParticleTypes(RegistryEvent.Register<ParticleType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.keySet().toArray(new ParticleType[0]));
	}

	@SubscribeEvent
	public static void registerParticles(ParticleFactoryRegisterEvent event) {
		REGISTRY.forEach((particle, provider) -> Minecraft.getInstance().particleEngine.register((SimpleParticleType) particle,
				spriteSet -> provider.apply(spriteSet)));
	}
}
