package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class WME1TrueProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			Entity entity = event.player;
			execute(event, entity);
		}
	}

	public static boolean execute(Entity entity) {
		return execute(null, entity);
	}

	private static boolean execute(@Nullable Event event, Entity entity) {
		if (entity == null)
			return false;
		boolean e = false;
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicKnowledge > 0.5) {
			e = true;
			return true;
		}
		if (e == true) {
			if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 != 3) {
				return true;
			}
		}
		return false;
	}
}
