
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chickennuggetacsnonconformist.init;

import org.lwjgl.glfw.GLFW;

import net.minecraftforge.fmlclient.registry.ClientRegistry;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.chickennuggetacsnonconformist.network.UpgradesKeybindMessage;
import net.mcreator.chickennuggetacsnonconformist.network.ManaShiftRegenMessage;
import net.mcreator.chickennuggetacsnonconformist.network.MagicAttack1Message;
import net.mcreator.chickennuggetacsnonconformist.network.GuildToolScrollMessage;
import net.mcreator.chickennuggetacsnonconformist.ChickennuggetacsNonconformistMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class ChickennuggetacsNonconformistModKeyMappings {
	public static final KeyMapping MAGIC_ATTACK_1 = new KeyMapping("key.chickennuggetacs_nonconformist.magic_attack_1", GLFW.GLFW_KEY_C,
			"key.categories.misc");
	public static final KeyMapping UPGRADES_KEYBIND = new KeyMapping("key.chickennuggetacs_nonconformist.upgrades_keybind", GLFW.GLFW_KEY_U,
			"key.categories.misc");
	public static final KeyMapping MANA_SHIFT_REGEN = new KeyMapping("key.chickennuggetacs_nonconformist.mana_shift_regen", GLFW.GLFW_KEY_LEFT_SHIFT,
			"key.categories.misc");
	public static final KeyMapping GUILD_TOOL_SCROLL = new KeyMapping("key.chickennuggetacs_nonconformist.guild_tool_scroll", GLFW.GLFW_KEY_M,
			"key.categories.misc");

	@SubscribeEvent
	public static void registerKeyBindings(FMLClientSetupEvent event) {
		ClientRegistry.registerKeyBinding(MAGIC_ATTACK_1);
		ClientRegistry.registerKeyBinding(UPGRADES_KEYBIND);
		ClientRegistry.registerKeyBinding(MANA_SHIFT_REGEN);
		ClientRegistry.registerKeyBinding(GUILD_TOOL_SCROLL);
	}

	@Mod.EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onKeyInput(InputEvent.KeyInputEvent event) {
			if (Minecraft.getInstance().screen == null) {
				if (event.getKey() == MAGIC_ATTACK_1.getKey().getValue()) {
					if (event.getAction() == GLFW.GLFW_PRESS) {
						ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new MagicAttack1Message(0, 0));
						MagicAttack1Message.pressAction(Minecraft.getInstance().player, 0, 0);
					}
				}
				if (event.getKey() == UPGRADES_KEYBIND.getKey().getValue()) {
					if (event.getAction() == GLFW.GLFW_PRESS) {
						ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new UpgradesKeybindMessage(0, 0));
						UpgradesKeybindMessage.pressAction(Minecraft.getInstance().player, 0, 0);
					}
				}
				if (event.getKey() == MANA_SHIFT_REGEN.getKey().getValue()) {
					if (event.getAction() == GLFW.GLFW_PRESS) {
						ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new ManaShiftRegenMessage(0, 0));
						ManaShiftRegenMessage.pressAction(Minecraft.getInstance().player, 0, 0);
					}
				}
				if (event.getKey() == GUILD_TOOL_SCROLL.getKey().getValue()) {
					if (event.getAction() == GLFW.GLFW_PRESS) {
						ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new GuildToolScrollMessage(0, 0));
						GuildToolScrollMessage.pressAction(Minecraft.getInstance().player, 0, 0);
					}
				}
			}
		}
	}
}
