
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chickennuggetacsnonconformist.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.chickennuggetacsnonconformist.client.renderer.WindRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.WindCircleRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.WaterRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.WaterCircleRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.SpiritRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.SpiritCircleRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.RoarRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.LightningRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.LightningEntityRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.LightningCircleRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.LightRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.LightCircleRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.FireRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.FireCircleRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.EarthRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.EarthCircleRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.DarkRenderer;
import net.mcreator.chickennuggetacsnonconformist.client.renderer.DarkCircleRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ChickennuggetacsNonconformistModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.ROAR, RoarRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.LIGHTNING, LightningRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.CASTING_OFFSET, ThrownItemRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.LIGHTNING_ENTITY, LightningEntityRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.FIRE, FireRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.WATER, WaterRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.WATER_CIRCLE, WaterCircleRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.FIRE_CIRCLE, FireCircleRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.EARTH_CIRCLE, EarthCircleRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.LIGHTNING_CIRCLE, LightningCircleRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.WIND, WindRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.WIND_CIRCLE, WindCircleRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.EARTH, EarthRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.DARK, DarkRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.LIGHT, LightRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.DARK_CIRCLE, DarkCircleRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.LIGHT_CIRCLE, LightCircleRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.SPIRIT, SpiritRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.SPIRIT_CIRCLE, SpiritCircleRenderer::new);
		event.registerEntityRenderer(ChickennuggetacsNonconformistModEntities.CUM_SHOT, ThrownItemRenderer::new);
	}
}
