
package net.mcreator.chickennuggetacsnonconformist.network;

import net.minecraftforge.fmllegacy.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.chickennuggetacsnonconformist.world.inventory.L1Menu;
import net.mcreator.chickennuggetacsnonconformist.procedures.LMS1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.LME1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.BM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.ChickennuggetacsNonconformistMod;

import java.util.function.Supplier;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class L1ButtonMessage {
	private final int buttonID, x, y, z;

	public L1ButtonMessage(FriendlyByteBuf buffer) {
		this.buttonID = buffer.readInt();
		this.x = buffer.readInt();
		this.y = buffer.readInt();
		this.z = buffer.readInt();
	}

	public L1ButtonMessage(int buttonID, int x, int y, int z) {
		this.buttonID = buttonID;
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static void buffer(L1ButtonMessage message, FriendlyByteBuf buffer) {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}

	public static void handler(L1ButtonMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
		NetworkEvent.Context context = contextSupplier.get();
		context.enqueueWork(() -> {
			Player entity = context.getSender();
			int buttonID = message.buttonID;
			int x = message.x;
			int y = message.y;
			int z = message.z;
			handleButtonAction(entity, buttonID, x, y, z);
		});
		context.setPacketHandled(true);
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level;
		HashMap guistate = L1Menu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			LMS1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 1) {

			BM1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 2) {

			LME1Procedure.execute(entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		ChickennuggetacsNonconformistMod.addNetworkMessage(L1ButtonMessage.class, L1ButtonMessage::buffer, L1ButtonMessage::new,
				L1ButtonMessage::handler);
	}
}
