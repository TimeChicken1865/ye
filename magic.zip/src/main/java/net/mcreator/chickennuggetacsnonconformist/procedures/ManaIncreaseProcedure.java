package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;

public class ManaIncreaseProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof Player _plr ? _plr.experienceLevel : 0) > 4) {
			if (entity instanceof Player _player)
				_player.giveExperienceLevels(-(5));
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MaxMana + 25;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.MaxMana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
