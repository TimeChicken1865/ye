
package net.mcreator.chickennuggetacsnonconformist.network;

import net.minecraftforge.fmllegacy.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.chickennuggetacsnonconformist.world.inventory.MagicAttack1GUIMenu;
import net.mcreator.chickennuggetacsnonconformist.procedures.WM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.SM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.LM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.LAM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.FM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.EM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.DM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.DAM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.BMM1Procedure;
import net.mcreator.chickennuggetacsnonconformist.ChickennuggetacsNonconformistMod;

import java.util.function.Supplier;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class MagicAttack1GUIButtonMessage {
	private final int buttonID, x, y, z;

	public MagicAttack1GUIButtonMessage(FriendlyByteBuf buffer) {
		this.buttonID = buffer.readInt();
		this.x = buffer.readInt();
		this.y = buffer.readInt();
		this.z = buffer.readInt();
	}

	public MagicAttack1GUIButtonMessage(int buttonID, int x, int y, int z) {
		this.buttonID = buttonID;
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static void buffer(MagicAttack1GUIButtonMessage message, FriendlyByteBuf buffer) {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}

	public static void handler(MagicAttack1GUIButtonMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
		NetworkEvent.Context context = contextSupplier.get();
		context.enqueueWork(() -> {
			Player entity = context.getSender();
			int buttonID = message.buttonID;
			int x = message.x;
			int y = message.y;
			int z = message.z;
			handleButtonAction(entity, buttonID, x, y, z);
		});
		context.setPacketHandled(true);
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level;
		HashMap guistate = MagicAttack1GUIMenu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			LM1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 1) {

			LAM1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 2) {

			DAM1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 4) {

			FM1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 5) {

			WM1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 6) {

			EM1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 7) {

			DM1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 9) {

			SM1Procedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 12) {

			BMM1Procedure.execute(world, x, y, z, entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		ChickennuggetacsNonconformistMod.addNetworkMessage(MagicAttack1GUIButtonMessage.class, MagicAttack1GUIButtonMessage::buffer,
				MagicAttack1GUIButtonMessage::new, MagicAttack1GUIButtonMessage::handler);
	}
}
