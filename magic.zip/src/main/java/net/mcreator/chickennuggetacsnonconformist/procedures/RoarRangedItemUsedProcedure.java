package net.mcreator.chickennuggetacsnonconformist.procedures;

public class RoarRangedItemUsedProcedure {
	public static void execute() {
	}
}
