
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chickennuggetacsnonconformist.init;

import net.minecraftforge.fmllegacy.network.IContainerFactory;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.AbstractContainerMenu;

import net.mcreator.chickennuggetacsnonconformist.world.inventory.WManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.W1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.UpgradesMenu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.SManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.S1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.RaceGUIMenu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.MagicMenu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.MagicAttack1GUIMenu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.LManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.LAManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.LA1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.L1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.HumanMenu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.GuildOwnerGUIHitMenu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.GuildGUIMenu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.FManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.F1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.EManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.E1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.DManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.DAManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.DA1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.D1Menu;
import net.mcreator.chickennuggetacsnonconformist.world.inventory.ConfirmimmuntiyresetMenu;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ChickennuggetacsNonconformistModMenus {
	private static final List<MenuType<?>> REGISTRY = new ArrayList<>();
	public static final MenuType<MagicMenu> MAGIC = register("magic", (id, inv, extraData) -> new MagicMenu(id, inv, extraData));
	public static final MenuType<MagicAttack1GUIMenu> MAGIC_ATTACK_1_GUI = register("magic_attack_1_gui",
			(id, inv, extraData) -> new MagicAttack1GUIMenu(id, inv, extraData));
	public static final MenuType<L1Menu> L_1 = register("l_1", (id, inv, extraData) -> new L1Menu(id, inv, extraData));
	public static final MenuType<LManipulation1Menu> L_MANIPULATION_1 = register("l_manipulation_1",
			(id, inv, extraData) -> new LManipulation1Menu(id, inv, extraData));
	public static final MenuType<UpgradesMenu> UPGRADES = register("upgrades", (id, inv, extraData) -> new UpgradesMenu(id, inv, extraData));
	public static final MenuType<RaceGUIMenu> RACE_GUI = register("race_gui", (id, inv, extraData) -> new RaceGUIMenu(id, inv, extraData));
	public static final MenuType<HumanMenu> HUMAN = register("human", (id, inv, extraData) -> new HumanMenu(id, inv, extraData));
	public static final MenuType<F1Menu> F_1 = register("f_1", (id, inv, extraData) -> new F1Menu(id, inv, extraData));
	public static final MenuType<FManipulation1Menu> F_MANIPULATION_1 = register("f_manipulation_1",
			(id, inv, extraData) -> new FManipulation1Menu(id, inv, extraData));
	public static final MenuType<W1Menu> W_1 = register("w_1", (id, inv, extraData) -> new W1Menu(id, inv, extraData));
	public static final MenuType<WManipulation1Menu> W_MANIPULATION_1 = register("w_manipulation_1",
			(id, inv, extraData) -> new WManipulation1Menu(id, inv, extraData));
	public static final MenuType<D1Menu> D_1 = register("d_1", (id, inv, extraData) -> new D1Menu(id, inv, extraData));
	public static final MenuType<DManipulation1Menu> D_MANIPULATION_1 = register("d_manipulation_1",
			(id, inv, extraData) -> new DManipulation1Menu(id, inv, extraData));
	public static final MenuType<E1Menu> E_1 = register("e_1", (id, inv, extraData) -> new E1Menu(id, inv, extraData));
	public static final MenuType<EManipulation1Menu> E_MANIPULATION_1 = register("e_manipulation_1",
			(id, inv, extraData) -> new EManipulation1Menu(id, inv, extraData));
	public static final MenuType<DA1Menu> DA_1 = register("da_1", (id, inv, extraData) -> new DA1Menu(id, inv, extraData));
	public static final MenuType<DAManipulation1Menu> DA_MANIPULATION_1 = register("da_manipulation_1",
			(id, inv, extraData) -> new DAManipulation1Menu(id, inv, extraData));
	public static final MenuType<GuildOwnerGUIHitMenu> GUILD_OWNER_GUI_HIT = register("guild_owner_gui_hit",
			(id, inv, extraData) -> new GuildOwnerGUIHitMenu(id, inv, extraData));
	public static final MenuType<GuildGUIMenu> GUILD_GUI = register("guild_gui", (id, inv, extraData) -> new GuildGUIMenu(id, inv, extraData));
	public static final MenuType<ConfirmimmuntiyresetMenu> CONFIRMIMMUNTIYRESET = register("confirmimmuntiyreset",
			(id, inv, extraData) -> new ConfirmimmuntiyresetMenu(id, inv, extraData));
	public static final MenuType<LA1Menu> LA_1 = register("la_1", (id, inv, extraData) -> new LA1Menu(id, inv, extraData));
	public static final MenuType<LAManipulation1Menu> LA_MANIPULATION_1 = register("la_manipulation_1",
			(id, inv, extraData) -> new LAManipulation1Menu(id, inv, extraData));
	public static final MenuType<S1Menu> S_1 = register("s_1", (id, inv, extraData) -> new S1Menu(id, inv, extraData));
	public static final MenuType<SManipulation1Menu> S_MANIPULATION_1 = register("s_manipulation_1",
			(id, inv, extraData) -> new SManipulation1Menu(id, inv, extraData));

	private static <T extends AbstractContainerMenu> MenuType<T> register(String registryname, IContainerFactory<T> containerFactory) {
		MenuType<T> menuType = new MenuType<T>(containerFactory);
		menuType.setRegistryName(registryname);
		REGISTRY.add(menuType);
		return menuType;
	}

	@SubscribeEvent
	public static void registerContainers(RegistryEvent.Register<MenuType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new MenuType[0]));
	}
}
