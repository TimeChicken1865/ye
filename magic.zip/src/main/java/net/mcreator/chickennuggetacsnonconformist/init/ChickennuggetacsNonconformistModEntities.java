
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chickennuggetacsnonconformist.init;

import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.entity.WindEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.WindCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.WaterEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.WaterCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.SpiritEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.SpiritCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.RoarEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.LightningEntityEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.LightningEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.LightningCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.LightEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.LightCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.FireEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.FireCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.EarthEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.EarthCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.DarkEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.DarkCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.CumShotEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.CastingOffsetEntity;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ChickennuggetacsNonconformistModEntities {
	private static final List<EntityType<?>> REGISTRY = new ArrayList<>();
	public static final EntityType<RoarEntity> ROAR = register("entitybulletroar",
			EntityType.Builder.<RoarEntity>of(RoarEntity::new, MobCategory.MISC).setCustomClientFactory(RoarEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<LightningEntity> LIGHTNING = register("entitybulletlightning",
			EntityType.Builder.<LightningEntity>of(LightningEntity::new, MobCategory.MISC).setCustomClientFactory(LightningEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<CastingOffsetEntity> CASTING_OFFSET = register("entitybulletcasting_offset",
			EntityType.Builder.<CastingOffsetEntity>of(CastingOffsetEntity::new, MobCategory.MISC).setCustomClientFactory(CastingOffsetEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<LightningEntityEntity> LIGHTNING_ENTITY = register("lightning_entity",
			EntityType.Builder.<LightningEntityEntity>of(LightningEntityEntity::new, MobCategory.MISC).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(LightningEntityEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<FireEntity> FIRE = register("entitybulletfire",
			EntityType.Builder.<FireEntity>of(FireEntity::new, MobCategory.MISC).setCustomClientFactory(FireEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<WaterEntity> WATER = register("entitybulletwater",
			EntityType.Builder.<WaterEntity>of(WaterEntity::new, MobCategory.MISC).setCustomClientFactory(WaterEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<WaterCircleEntity> WATER_CIRCLE = register("water_circle",
			EntityType.Builder.<WaterCircleEntity>of(WaterCircleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WaterCircleEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<FireCircleEntity> FIRE_CIRCLE = register("fire_circle",
			EntityType.Builder.<FireCircleEntity>of(FireCircleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(FireCircleEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<EarthCircleEntity> EARTH_CIRCLE = register("earth_circle",
			EntityType.Builder.<EarthCircleEntity>of(EarthCircleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EarthCircleEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<LightningCircleEntity> LIGHTNING_CIRCLE = register("lightning_circle",
			EntityType.Builder.<LightningCircleEntity>of(LightningCircleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(LightningCircleEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<WindEntity> WIND = register("entitybulletwind",
			EntityType.Builder.<WindEntity>of(WindEntity::new, MobCategory.MISC).setCustomClientFactory(WindEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<WindCircleEntity> WIND_CIRCLE = register("wind_circle",
			EntityType.Builder.<WindCircleEntity>of(WindCircleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(WindCircleEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<EarthEntity> EARTH = register("entitybulletearth",
			EntityType.Builder.<EarthEntity>of(EarthEntity::new, MobCategory.MISC).setCustomClientFactory(EarthEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<DarkEntity> DARK = register("entitybulletdark",
			EntityType.Builder.<DarkEntity>of(DarkEntity::new, MobCategory.MISC).setCustomClientFactory(DarkEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<LightEntity> LIGHT = register("entitybulletlight",
			EntityType.Builder.<LightEntity>of(LightEntity::new, MobCategory.MISC).setCustomClientFactory(LightEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<DarkCircleEntity> DARK_CIRCLE = register("dark_circle",
			EntityType.Builder.<DarkCircleEntity>of(DarkCircleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DarkCircleEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<LightCircleEntity> LIGHT_CIRCLE = register("light_circle",
			EntityType.Builder.<LightCircleEntity>of(LightCircleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(LightCircleEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<SpiritEntity> SPIRIT = register("entitybulletspirit",
			EntityType.Builder.<SpiritEntity>of(SpiritEntity::new, MobCategory.MISC).setCustomClientFactory(SpiritEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));
	public static final EntityType<SpiritCircleEntity> SPIRIT_CIRCLE = register("spirit_circle",
			EntityType.Builder.<SpiritCircleEntity>of(SpiritCircleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
					.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(SpiritCircleEntity::new).sized(0.6f, 1.8f));
	public static final EntityType<CumShotEntity> CUM_SHOT = register("entitybulletcum_shot",
			EntityType.Builder.<CumShotEntity>of(CumShotEntity::new, MobCategory.MISC).setCustomClientFactory(CumShotEntity::new)
					.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(1).sized(0.5f, 0.5f));

	private static <T extends Entity> EntityType<T> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		EntityType<T> entityType = (EntityType<T>) entityTypeBuilder.build(registryname).setRegistryName(registryname);
		REGISTRY.add(entityType);
		return entityType;
	}

	@SubscribeEvent
	public static void registerEntities(RegistryEvent.Register<EntityType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new EntityType[0]));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			LightningEntityEntity.init();
			WaterCircleEntity.init();
			FireCircleEntity.init();
			EarthCircleEntity.init();
			LightningCircleEntity.init();
			WindCircleEntity.init();
			DarkCircleEntity.init();
			LightCircleEntity.init();
			SpiritCircleEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(LIGHTNING_ENTITY, LightningEntityEntity.createAttributes().build());
		event.put(WATER_CIRCLE, WaterCircleEntity.createAttributes().build());
		event.put(FIRE_CIRCLE, FireCircleEntity.createAttributes().build());
		event.put(EARTH_CIRCLE, EarthCircleEntity.createAttributes().build());
		event.put(LIGHTNING_CIRCLE, LightningCircleEntity.createAttributes().build());
		event.put(WIND_CIRCLE, WindCircleEntity.createAttributes().build());
		event.put(DARK_CIRCLE, DarkCircleEntity.createAttributes().build());
		event.put(LIGHT_CIRCLE, LightCircleEntity.createAttributes().build());
		event.put(SPIRIT_CIRCLE, SpiritCircleEntity.createAttributes().build());
	}
}
