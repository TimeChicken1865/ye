// Made with Blockbench 4.1.3
// Exported for Minecraft version 1.17 with Mojang mappings
// Paste this class into your mod and generate all required imports

public class ModelWindCircle<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "windcircle"), "main");
	private final ModelPart bone;
	private final ModelPart bone3;
	private final ModelPart bone5;
	private final ModelPart bone7;
	private final ModelPart bone9;
	private final ModelPart bone11;
	private final ModelPart bone13;
	private final ModelPart bone15;
	private final ModelPart bone17;
	private final ModelPart bone18;
	private final ModelPart bone19;
	private final ModelPart bone20;
	private final ModelPart bb_main;

	public ModelWindCircle(ModelPart root) {
		this.bone = root.getChild("bone");
		this.bone3 = root.getChild("bone3");
		this.bone5 = root.getChild("bone5");
		this.bone7 = root.getChild("bone7");
		this.bone9 = root.getChild("bone9");
		this.bone11 = root.getChild("bone11");
		this.bone13 = root.getChild("bone13");
		this.bone15 = root.getChild("bone15");
		this.bone17 = root.getChild("bone17");
		this.bone18 = root.getChild("bone18");
		this.bone19 = root.getChild("bone19");
		this.bone20 = root.getChild("bone20");
		this.bb_main = root.getChild("bb_main");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition bone = partdefinition.addOrReplaceChild("bone",
				CubeListBuilder.create().texOffs(0, 36)
						.addBox(-14.0F, -1.0F, -15.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 18)
						.addBox(-12.0F, -1.0F, -16.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 20)
						.addBox(-9.0F, -1.0F, -17.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 36)
						.addBox(-6.0F, -1.0F, -18.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 22)
						.addBox(-3.0F, -1.0F, -19.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition bone2 = bone.addOrReplaceChild("bone2",
				CubeListBuilder.create().texOffs(29, 35)
						.addBox(3.7F, -0.5F, 1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(35, 15)
						.addBox(1.7F, -0.5F, 0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(15, 35)
						.addBox(-1.3F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 35)
						.addBox(-4.3F, -0.5F, -1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(35, 0)
						.addBox(-7.3F, -0.5F, -2.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-16.7F, -0.5F, -6.5F, 0.0F, -1.5708F, 0.0F));

		PartDefinition bone3 = partdefinition.addOrReplaceChild("bone3",
				CubeListBuilder.create().texOffs(22, 34)
						.addBox(11.0F, -1.0F, -15.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(34, 12)
						.addBox(9.0F, -1.0F, -16.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 34)
						.addBox(6.0F, -1.0F, -17.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(29, 33)
						.addBox(3.0F, -1.0F, -18.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(15, 33)
						.addBox(0.0F, -1.0F, -19.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition bone4 = bone3.addOrReplaceChild("bone4",
				CubeListBuilder.create().texOffs(33, 9)
						.addBox(-6.7F, -0.5F, 1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 33)
						.addBox(-4.7F, -0.5F, 0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 32)
						.addBox(-1.7F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(32, 7)
						.addBox(1.3F, -0.5F, -1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 32)
						.addBox(4.3F, -0.5F, -2.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(16.7F, -0.5F, -6.5F, 0.0F, 1.5708F, 0.0F));

		PartDefinition bone5 = partdefinition.addOrReplaceChild("bone5",
				CubeListBuilder.create().texOffs(29, 31)
						.addBox(-14.0F, -1.0F, 14.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(15, 31)
						.addBox(-12.0F, -1.0F, 15.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 31)
						.addBox(-9.0F, -1.0F, 16.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 30)
						.addBox(-6.0F, -1.0F, 17.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(30, 4)
						.addBox(-3.0F, -1.0F, 18.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition bone6 = bone5.addOrReplaceChild("bone6",
				CubeListBuilder.create().texOffs(0, 30)
						.addBox(3.7F, -0.5F, -2.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(29, 29)
						.addBox(1.7F, -0.5F, -1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(29, 27)
						.addBox(-1.3F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(29, 25)
						.addBox(-4.3F, -0.5F, 0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(29, 23)
						.addBox(-7.3F, -0.5F, 1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-16.7F, -0.5F, 6.5F, 0.0F, 1.5708F, 0.0F));

		PartDefinition bone7 = partdefinition.addOrReplaceChild("bone7",
				CubeListBuilder.create().texOffs(29, 21)
						.addBox(11.0F, -1.0F, 14.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(29, 19)
						.addBox(9.0F, -1.0F, 15.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(29, 17)
						.addBox(6.0F, -1.0F, 16.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(15, 29)
						.addBox(3.0F, -1.0F, 17.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 29)
						.addBox(0.0F, -1.0F, 18.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition bone8 = bone7.addOrReplaceChild("bone8",
				CubeListBuilder.create().texOffs(29, 2)
						.addBox(-6.7F, -0.5F, -2.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 28)
						.addBox(-4.7F, -0.5F, -1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(28, 14)
						.addBox(-1.7F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 28)
						.addBox(1.3F, -0.5F, 0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(15, 27)
						.addBox(4.3F, -0.5F, 1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(16.7F, -0.5F, 6.5F, 0.0F, -1.5708F, 0.0F));

		PartDefinition bone9 = partdefinition.addOrReplaceChild("bone9",
				CubeListBuilder.create().texOffs(27, 11)
						.addBox(11.0F, -1.0F, -15.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 27)
						.addBox(9.0F, -1.0F, -16.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(27, 0)
						.addBox(6.0F, -1.0F, -17.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 26)
						.addBox(3.0F, -1.0F, -18.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 26)
						.addBox(0.0F, -1.0F, -19.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-4.0F, 24.0F, 4.0F));

		PartDefinition bone10 = bone9.addOrReplaceChild("bone10",
				CubeListBuilder.create().texOffs(15, 25)
						.addBox(-6.7F, -0.5F, 1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(25, 9)
						.addBox(-4.7F, -0.5F, 0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 25)
						.addBox(-1.7F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(25, 6)
						.addBox(1.3F, -0.5F, -1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 24)
						.addBox(4.3F, -0.5F, -2.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(16.7F, -0.5F, -6.5F, 0.0F, 1.5708F, 0.0F));

		PartDefinition bone11 = partdefinition.addOrReplaceChild("bone11",
				CubeListBuilder.create().texOffs(0, 24)
						.addBox(11.0F, -1.0F, 14.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(15, 23)
						.addBox(9.0F, -1.0F, 15.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 23)
						.addBox(6.0F, -1.0F, 16.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 22)
						.addBox(3.0F, -1.0F, 17.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 20)
						.addBox(0.0F, -1.0F, 18.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-4.0F, 24.0F, -4.0F));

		PartDefinition bone12 = bone11.addOrReplaceChild("bone12",
				CubeListBuilder.create().texOffs(22, 18)
						.addBox(-6.7F, -0.5F, -2.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 16)
						.addBox(-4.7F, -0.5F, -1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(22, 4)
						.addBox(-1.7F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 22)
						.addBox(1.3F, -0.5F, 0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(15, 21)
						.addBox(4.3F, -0.5F, 1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(16.7F, -0.5F, 6.5F, 0.0F, -1.5708F, 0.0F));

		PartDefinition bone13 = partdefinition.addOrReplaceChild("bone13",
				CubeListBuilder.create().texOffs(21, 13)
						.addBox(-14.0F, -1.0F, 14.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 21)
						.addBox(-12.0F, -1.0F, 15.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(21, 2)
						.addBox(-9.0F, -1.0F, 16.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 20)
						.addBox(-6.0F, -1.0F, 17.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(15, 19)
						.addBox(-3.0F, -1.0F, 18.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(4.0F, 24.0F, -4.0F));

		PartDefinition bone14 = bone13.addOrReplaceChild("bone14",
				CubeListBuilder.create().texOffs(19, 11)
						.addBox(3.7F, -0.5F, -2.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 19)
						.addBox(1.7F, -0.5F, -1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(19, 0)
						.addBox(-1.3F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(18, 8)
						.addBox(-4.3F, -0.5F, 0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 18)
						.addBox(-7.3F, -0.5F, 1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-16.7F, -0.5F, 6.5F, 0.0F, 1.5708F, 0.0F));

		PartDefinition bone15 = partdefinition.addOrReplaceChild("bone15",
				CubeListBuilder.create().texOffs(15, 17)
						.addBox(-14.0F, -1.0F, -15.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 17)
						.addBox(-12.0F, -1.0F, -16.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(17, 6)
						.addBox(-9.0F, -1.0F, -17.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 16)
						.addBox(-6.0F, -1.0F, -18.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(15, 15)
						.addBox(-3.0F, -1.0F, -19.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(4.0F, 24.0F, 4.0F));

		PartDefinition bone16 = bone15.addOrReplaceChild("bone16",
				CubeListBuilder.create().texOffs(7, 15)
						.addBox(3.7F, -0.5F, 1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(14, 4)
						.addBox(1.7F, -0.5F, 0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 14)
						.addBox(-1.3F, -0.5F, -0.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(13, 13)
						.addBox(-4.3F, -0.5F, -1.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(13, 2)
						.addBox(-7.3F, -0.5F, -2.5F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-16.7F, -0.5F, -6.5F, 0.0F, -1.5708F, 0.0F));

		PartDefinition bone17 = partdefinition.addOrReplaceChild("bone17",
				CubeListBuilder.create().texOffs(36, 36)
						.addBox(16.0F, -1.0F, -0.25F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 34)
						.addBox(13.25F, -1.0F, 6.75F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(11, 6)
						.addBox(11.0F, -1.0F, 10.75F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition bone18 = partdefinition.addOrReplaceChild("bone18",
				CubeListBuilder.create().texOffs(36, 32)
						.addBox(-17.0F, -1.0F, -0.75F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 30)
						.addBox(-14.25F, -1.0F, -7.75F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(6, 11)
						.addBox(-13.0F, -1.0F, -12.75F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition bone19 = partdefinition.addOrReplaceChild("bone19",
				CubeListBuilder.create().texOffs(36, 28)
						.addBox(16.0F, -1.0F, -0.75F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 26)
						.addBox(13.25F, -1.0F, -7.75F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(5, 8)
						.addBox(11.0F, -1.0F, -12.75F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition bone20 = partdefinition.addOrReplaceChild("bone20",
				CubeListBuilder.create().texOffs(36, 24)
						.addBox(-17.0F, -1.0F, -0.25F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 12)
						.addBox(-14.25F, -1.0F, 6.75F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(7, 2)
						.addBox(-13.0F, -1.0F, 10.75F, 2.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition bb_main = partdefinition.addOrReplaceChild("bb_main",
				CubeListBuilder.create().texOffs(7, 0)
						.addBox(-2.0F, -1.0F, -4.0F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 0)
						.addBox(-3.0F, -1.0F, -3.0F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(0, 6)
						.addBox(-2.0F, -1.0F, 2.0F, 5.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 8)
						.addBox(3.0F, -1.0F, -1.0F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(12, 10)
						.addBox(0.0F, -1.0F, -2.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 2)
						.addBox(-1.0F, -1.0F, -1.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 0)
						.addBox(0.0F, -1.0F, 0.0F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		bone.render(poseStack, buffer, packedLight, packedOverlay);
		bone3.render(poseStack, buffer, packedLight, packedOverlay);
		bone5.render(poseStack, buffer, packedLight, packedOverlay);
		bone7.render(poseStack, buffer, packedLight, packedOverlay);
		bone9.render(poseStack, buffer, packedLight, packedOverlay);
		bone11.render(poseStack, buffer, packedLight, packedOverlay);
		bone13.render(poseStack, buffer, packedLight, packedOverlay);
		bone15.render(poseStack, buffer, packedLight, packedOverlay);
		bone17.render(poseStack, buffer, packedLight, packedOverlay);
		bone18.render(poseStack, buffer, packedLight, packedOverlay);
		bone19.render(poseStack, buffer, packedLight, packedOverlay);
		bone20.render(poseStack, buffer, packedLight, packedOverlay);
		bb_main.render(poseStack, buffer, packedLight, packedOverlay);
	}
}