package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;
import net.mcreator.chickennuggetacsnonconformist.entity.LightningEntity;

public class CSProcedure {
	public static void execute(Entity entity, Entity imediatesourceentity, Entity sourceentity) {
		if (entity == null || imediatesourceentity == null || sourceentity == null)
			return;
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 == 1) {
			if (imediatesourceentity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
				LightningEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
						(float) ((sourceentity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 0.3),
						(float) ((sourceentity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage + 2),
						0);
			}
		}
	}
}
