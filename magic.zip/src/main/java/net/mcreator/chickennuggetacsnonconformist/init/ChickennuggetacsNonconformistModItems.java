
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.chickennuggetacsnonconformist.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;

import net.mcreator.chickennuggetacsnonconformist.item.WindItem;
import net.mcreator.chickennuggetacsnonconformist.item.WaterItem;
import net.mcreator.chickennuggetacsnonconformist.item.SpiritItem;
import net.mcreator.chickennuggetacsnonconformist.item.RoarItem;
import net.mcreator.chickennuggetacsnonconformist.item.LightningItem;
import net.mcreator.chickennuggetacsnonconformist.item.LightItem;
import net.mcreator.chickennuggetacsnonconformist.item.GuildStaffRankIncreaseItem;
import net.mcreator.chickennuggetacsnonconformist.item.GuildStaffRankDecreaseItem;
import net.mcreator.chickennuggetacsnonconformist.item.GuildStaffKickItem;
import net.mcreator.chickennuggetacsnonconformist.item.GuildStaffItem;
import net.mcreator.chickennuggetacsnonconformist.item.FireItem;
import net.mcreator.chickennuggetacsnonconformist.item.EarthItem;
import net.mcreator.chickennuggetacsnonconformist.item.DarkItem;
import net.mcreator.chickennuggetacsnonconformist.item.CumShotItem;
import net.mcreator.chickennuggetacsnonconformist.item.CastingOffsetItem;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ChickennuggetacsNonconformistModItems {
	private static final List<Item> REGISTRY = new ArrayList<>();
	public static final Item ROAR = register(new RoarItem());
	public static final Item LIGHTNING = register(new LightningItem());
	public static final Item CASTING_OFFSET = register(new CastingOffsetItem());
	public static final Item LIGHTNING_ENTITY = register(
			new SpawnEggItem(ChickennuggetacsNonconformistModEntities.LIGHTNING_ENTITY, -1, -1, new Item.Properties().tab(CreativeModeTab.TAB_MISC))
					.setRegistryName("lightning_entity_spawn_egg"));
	public static final Item FIRE = register(new FireItem());
	public static final Item WATER = register(new WaterItem());
	public static final Item WATER_CIRCLE = register(
			new SpawnEggItem(ChickennuggetacsNonconformistModEntities.WATER_CIRCLE, -16776961, -3355444, new Item.Properties().tab(null))
					.setRegistryName("water_circle_spawn_egg"));
	public static final Item FIRE_CIRCLE = register(
			new SpawnEggItem(ChickennuggetacsNonconformistModEntities.FIRE_CIRCLE, -26368, -3355444, new Item.Properties().tab(null))
					.setRegistryName("fire_circle_spawn_egg"));
	public static final Item EARTH_CIRCLE = register(
			new SpawnEggItem(ChickennuggetacsNonconformistModEntities.EARTH_CIRCLE, -10079488, -3355444, new Item.Properties().tab(null))
					.setRegistryName("earth_circle_spawn_egg"));
	public static final Item LIGHTNING_CIRCLE = register(
			new SpawnEggItem(ChickennuggetacsNonconformistModEntities.LIGHTNING_CIRCLE, -205, -3355444, new Item.Properties().tab(null))
					.setRegistryName("lightning_circle_spawn_egg"));
	public static final Item WIND = register(new WindItem());
	public static final Item WIND_CIRCLE = register(
			new SpawnEggItem(ChickennuggetacsNonconformistModEntities.WIND_CIRCLE, -6710887, -3355444, new Item.Properties().tab(null))
					.setRegistryName("wind_circle_spawn_egg"));
	public static final Item EARTH = register(new EarthItem());
	public static final Item DARK = register(new DarkItem());
	public static final Item GUILD_STAFF = register(new GuildStaffItem());
	public static final Item GUILD_STAFF_RANK_INCREASE = register(new GuildStaffRankIncreaseItem());
	public static final Item GUILD_STAFF_RANK_DECREASE = register(new GuildStaffRankDecreaseItem());
	public static final Item GUILD_STAFF_KICK = register(new GuildStaffKickItem());
	public static final Item LIGHT = register(new LightItem());
	public static final Item DARK_CIRCLE = register(
			new SpawnEggItem(ChickennuggetacsNonconformistModEntities.DARK_CIRCLE, -16777216, -3355444, new Item.Properties().tab(null))
					.setRegistryName("dark_circle_spawn_egg"));
	public static final Item LIGHT_CIRCLE = register(
			new SpawnEggItem(ChickennuggetacsNonconformistModEntities.LIGHT_CIRCLE, -256, -3355444, new Item.Properties().tab(null))
					.setRegistryName("light_circle_spawn_egg"));
	public static final Item SPIRIT = register(new SpiritItem());
	public static final Item SPIRIT_CIRCLE = register(
			new SpawnEggItem(ChickennuggetacsNonconformistModEntities.SPIRIT_CIRCLE, -16711732, -3355444, new Item.Properties().tab(null))
					.setRegistryName("spirit_circle_spawn_egg"));
	public static final Item CUM_SHOT = register(new CumShotItem());

	private static Item register(Item item) {
		REGISTRY.add(item);
		return item;
	}

	@SubscribeEvent
	public static void registerItems(RegistryEvent.Register<Item> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new Item[0]));
	}
}
