package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;

public class MagicLength1DownProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength - 1;
			entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.MagicLength = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
	}
}
