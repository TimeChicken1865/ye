package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;

public class SME1Procedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = 8;
			entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.MagicType1 = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
	}
}
