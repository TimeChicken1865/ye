package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.chickennuggetacsnonconformist.init.ChickennuggetacsNonconformistModEntities;
import net.mcreator.chickennuggetacsnonconformist.entity.WindCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.WaterCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.SpiritCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.LightningCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.LightCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.FireCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.EarthCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.DarkCircleEntity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class CirclesProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			Entity entity = event.player;
			execute(event, entity.level, entity.getX(), entity.getY(), entity.getZ(), entity);
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBoolean("lightning") == true) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new LightningCircleEntity(ChickennuggetacsNonconformistModEntities.LIGHTNING_CIRCLE, _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (entity.getPersistentData().getBoolean("earth") == true) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new EarthCircleEntity(ChickennuggetacsNonconformistModEntities.EARTH_CIRCLE, _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (entity.getPersistentData().getBoolean("fire") == true) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new FireCircleEntity(ChickennuggetacsNonconformistModEntities.FIRE_CIRCLE, _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (entity.getPersistentData().getBoolean("water") == true) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WaterCircleEntity(ChickennuggetacsNonconformistModEntities.WATER_CIRCLE, _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (entity.getPersistentData().getBoolean("wind") == true) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new WindCircleEntity(ChickennuggetacsNonconformistModEntities.WIND_CIRCLE, _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (entity.getPersistentData().getBoolean("dark") == true) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new DarkCircleEntity(ChickennuggetacsNonconformistModEntities.DARK_CIRCLE, _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (entity.getPersistentData().getBoolean("light") == true) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new LightCircleEntity(ChickennuggetacsNonconformistModEntities.LIGHT_CIRCLE, _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
		if (entity.getPersistentData().getBoolean("spirit") == true) {
			if (world instanceof ServerLevel _level) {
				Entity entityToSpawn = new SpiritCircleEntity(ChickennuggetacsNonconformistModEntities.SPIRIT_CIRCLE, _level);
				entityToSpawn.moveTo(x, y, z, world.getRandom().nextFloat() * 360F, 0);
				if (entityToSpawn instanceof Mob _mobToSpawn)
					_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED, null,
							null);
				world.addFreshEntity(entityToSpawn);
			}
		}
	}
}
