package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;
import net.mcreator.chickennuggetacsnonconformist.entity.LightningEntity;

public class CastingOffsetWhileProjectileFlyingTickProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		double ye = 0;
		if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
			LightningEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
					(float) (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed,
					(float) (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage,
					0);
		}
	}
}
