package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.network.chat.TextComponent;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;

public class KickFromGuildProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).Guild_Rank < (sourceentity
						.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).Guild_Rank) {
			{
				double _setval = entity.getYRot() + entity.getXRot();
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.immunity = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			if (entity instanceof Player _player && !_player.level.isClientSide())
				_player.displayClientMessage(new TextComponent("kicked from guild"), (false));
			if (sourceentity instanceof Player _player && !_player.level.isClientSide())
				_player.displayClientMessage(new TextComponent("member kicked from guild"), (false));
			{
				double _setval = 1;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.Guild_Rank = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
		}
	}
}
