
package net.mcreator.chickennuggetacsnonconformist.network;

import net.minecraftforge.fmllegacy.network.NetworkEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.core.BlockPos;

import net.mcreator.chickennuggetacsnonconformist.world.inventory.SManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.procedures.SpiritBackProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicWidth1UpProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicWidth1DownProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicSpeed1UpProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicSpeed1DownProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicOffset1UpProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicOffset1DownProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicLength1UpProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicLength1DownProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicDamage1UpProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicDamage1DownProcedure;
import net.mcreator.chickennuggetacsnonconformist.ChickennuggetacsNonconformistMod;

import java.util.function.Supplier;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class SManipulation1ButtonMessage {
	private final int buttonID, x, y, z;

	public SManipulation1ButtonMessage(FriendlyByteBuf buffer) {
		this.buttonID = buffer.readInt();
		this.x = buffer.readInt();
		this.y = buffer.readInt();
		this.z = buffer.readInt();
	}

	public SManipulation1ButtonMessage(int buttonID, int x, int y, int z) {
		this.buttonID = buttonID;
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public static void buffer(SManipulation1ButtonMessage message, FriendlyByteBuf buffer) {
		buffer.writeInt(message.buttonID);
		buffer.writeInt(message.x);
		buffer.writeInt(message.y);
		buffer.writeInt(message.z);
	}

	public static void handler(SManipulation1ButtonMessage message, Supplier<NetworkEvent.Context> contextSupplier) {
		NetworkEvent.Context context = contextSupplier.get();
		context.enqueueWork(() -> {
			Player entity = context.getSender();
			int buttonID = message.buttonID;
			int x = message.x;
			int y = message.y;
			int z = message.z;
			handleButtonAction(entity, buttonID, x, y, z);
		});
		context.setPacketHandled(true);
	}

	public static void handleButtonAction(Player entity, int buttonID, int x, int y, int z) {
		Level world = entity.level;
		HashMap guistate = SManipulation1Menu.guistate;
		// security measure to prevent arbitrary chunk generation
		if (!world.hasChunkAt(new BlockPos(x, y, z)))
			return;
		if (buttonID == 0) {

			MagicSpeed1UpProcedure.execute(entity);
		}
		if (buttonID == 1) {

			MagicSpeed1DownProcedure.execute(entity);
		}
		if (buttonID == 2) {

			MagicDamage1DownProcedure.execute(entity);
		}
		if (buttonID == 3) {

			MagicDamage1UpProcedure.execute(entity);
		}
		if (buttonID == 4) {

			MagicWidth1DownProcedure.execute(entity);
		}
		if (buttonID == 5) {

			MagicWidth1UpProcedure.execute(entity);
		}
		if (buttonID == 6) {

			MagicLength1DownProcedure.execute(entity);
		}
		if (buttonID == 7) {

			MagicLength1UpProcedure.execute(entity);
		}
		if (buttonID == 8) {

			SpiritBackProcedure.execute(world, x, y, z, entity);
		}
		if (buttonID == 9) {

			MagicOffset1UpProcedure.execute(entity);
		}
		if (buttonID == 10) {

			MagicOffset1DownProcedure.execute(entity);
		}
	}

	@SubscribeEvent
	public static void registerMessage(FMLCommonSetupEvent event) {
		ChickennuggetacsNonconformistMod.addNetworkMessage(SManipulation1ButtonMessage.class, SManipulation1ButtonMessage::buffer,
				SManipulation1ButtonMessage::new, SManipulation1ButtonMessage::handler);
	}
}
