
package net.mcreator.chickennuggetacsnonconformist.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.Minecraft;

import net.mcreator.chickennuggetacsnonconformist.world.inventory.LManipulation1Menu;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicWidthLowTrueProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicSpeedLowTrueProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicOffsetLowTrueProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicLengthLowTrueProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.MagicDamageLowTrueProcedure;
import net.mcreator.chickennuggetacsnonconformist.network.LManipulation1ButtonMessage;
import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;
import net.mcreator.chickennuggetacsnonconformist.ChickennuggetacsNonconformistMod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

public class LManipulation1Screen extends AbstractContainerScreen<LManipulation1Menu> {
	private final Level world;
	private final int x, y, z;
	private final Player entity;

	public LManipulation1Screen(LManipulation1Menu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 0;
		this.imageHeight = 0;
	}

	private static final ResourceLocation texture = new ResourceLocation("chickennuggetacs_nonconformist:textures/l_manipulation_1.png");

	@Override
	public void render(PoseStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void renderBg(PoseStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderTexture(0, texture);
		this.blit(ms, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(PoseStack poseStack, int mouseX, int mouseY) {
		this.font.draw(poseStack, "speed", -155, -80, -256);
		this.font.draw(poseStack, "Damage", 137, -79, -256);
		this.font.draw(poseStack, "Width", -87, -8, -256);
		this.font.draw(poseStack, "Length", 66, -8, -256);
		this.font.draw(poseStack, "Caution: Mana cost changes based on edits", -106, 72, -65536);
		this.font.draw(poseStack, "Lightning Manipulation Magic", -66, -112, -256);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage) + "", 141, -94, -256);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicThickness) + "", -89, -30, -256);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength) + "", 69, -30, -256);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed) + "", -154, -98, -256);
		this.font.draw(poseStack, "offset", -12, 40, -256);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset) + "", -16, 22, -256);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardHandler.setSendRepeatsToGui(false);
	}

	@Override
	public void init() {
		super.init();
		this.minecraft.keyboardHandler.setSendRepeatsToGui(true);
		this.addRenderableWidget(new Button(this.leftPos + -121, this.topPos + -85, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(0, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -191, this.topPos + -85, 30, 20, new TextComponent("<"), e -> {
			if (MagicSpeedLowTrueProcedure.execute(entity)) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(1, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}) {
			@Override
			public void render(PoseStack ms, int gx, int gy, float ticks) {
				if (MagicSpeedLowTrueProcedure.execute(entity))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addRenderableWidget(new Button(this.leftPos + 102, this.topPos + -84, 30, 20, new TextComponent("<"), e -> {
			if (MagicDamageLowTrueProcedure.execute(entity)) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(2, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}) {
			@Override
			public void render(PoseStack ms, int gx, int gy, float ticks) {
				if (MagicDamageLowTrueProcedure.execute(entity))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addRenderableWidget(new Button(this.leftPos + 173, this.topPos + -83, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(3, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -125, this.topPos + -13, 30, 20, new TextComponent("<"), e -> {
			if (MagicWidthLowTrueProcedure.execute(entity)) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(4, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 4, x, y, z);
			}
		}) {
			@Override
			public void render(PoseStack ms, int gx, int gy, float ticks) {
				if (MagicWidthLowTrueProcedure.execute(entity))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addRenderableWidget(new Button(this.leftPos + -55, this.topPos + -13, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(5, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 5, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 28, this.topPos + -13, 30, 20, new TextComponent("<"), e -> {
			if (MagicLengthLowTrueProcedure.execute(entity)) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(6, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 6, x, y, z);
			}
		}) {
			@Override
			public void render(PoseStack ms, int gx, int gy, float ticks) {
				if (MagicLengthLowTrueProcedure.execute(entity))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addRenderableWidget(new Button(this.leftPos + 109, this.topPos + -13, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(7, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 7, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -208, this.topPos + -117, 46, 20, new TextComponent("Back"), e -> {
			if (true) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(8, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 8, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + 27, this.topPos + 35, 30, 20, new TextComponent(">"), e -> {
			if (true) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(9, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 9, x, y, z);
			}
		}));
		this.addRenderableWidget(new Button(this.leftPos + -56, this.topPos + 35, 30, 20, new TextComponent("<"), e -> {
			if (MagicOffsetLowTrueProcedure.execute(entity)) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new LManipulation1ButtonMessage(10, x, y, z));
				LManipulation1ButtonMessage.handleButtonAction(entity, 10, x, y, z);
			}
		}) {
			@Override
			public void render(PoseStack ms, int gx, int gy, float ticks) {
				if (MagicOffsetLowTrueProcedure.execute(entity))
					super.render(ms, gx, gy, ticks);
			}
		});
	}
}
