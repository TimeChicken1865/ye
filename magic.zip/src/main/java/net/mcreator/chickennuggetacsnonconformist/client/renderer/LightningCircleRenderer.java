package net.mcreator.chickennuggetacsnonconformist.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.chickennuggetacsnonconformist.entity.LightningCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.client.model.ModelThunderCircle;

public class LightningCircleRenderer extends MobRenderer<LightningCircleEntity, ModelThunderCircle<LightningCircleEntity>> {
	public LightningCircleRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelThunderCircle(context.bakeLayer(ModelThunderCircle.LAYER_LOCATION)), 0.5f);
		this.addLayer(new EyesLayer<LightningCircleEntity, ModelThunderCircle<LightningCircleEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("chickennuggetacs_nonconformist:textures/thundercircle.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(LightningCircleEntity entity) {
		return new ResourceLocation("chickennuggetacs_nonconformist:textures/invis.png");
	}
}
