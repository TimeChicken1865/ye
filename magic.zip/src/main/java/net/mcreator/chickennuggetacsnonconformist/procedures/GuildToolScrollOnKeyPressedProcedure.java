package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.TextComponent;

import net.mcreator.chickennuggetacsnonconformist.init.ChickennuggetacsNonconformistModItems;

public class GuildToolScrollOnKeyPressedProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getDouble("scroll") == 3) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
					.getItem() == ChickennuggetacsNonconformistModItems.GUILD_STAFF_KICK) {
				if (entity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("switched to invite member guild staff"), (false));
				if (entity instanceof LivingEntity _entity) {
					ItemStack _setstack = new ItemStack(ChickennuggetacsNonconformistModItems.GUILD_STAFF);
					_setstack.setCount(1);
					_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
					if (_entity instanceof ServerPlayer _serverPlayer)
						_serverPlayer.getInventory().setChanged();
				}
				entity.getPersistentData().putDouble("scroll", 4);
			}
		}
		if (entity.getPersistentData().getDouble("scroll") == 2) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
					.getItem() == ChickennuggetacsNonconformistModItems.GUILD_STAFF_RANK_DECREASE) {
				if (entity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("switched to kick member guild staff"), (false));
				if (entity instanceof LivingEntity _entity) {
					ItemStack _setstack = new ItemStack(ChickennuggetacsNonconformistModItems.GUILD_STAFF_KICK);
					_setstack.setCount(1);
					_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
					if (_entity instanceof ServerPlayer _serverPlayer)
						_serverPlayer.getInventory().setChanged();
				}
				entity.getPersistentData().putDouble("scroll", 3);
			}
		}
		if (entity.getPersistentData().getDouble("scroll") == 1) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
					.getItem() == ChickennuggetacsNonconformistModItems.GUILD_STAFF_RANK_INCREASE) {
				if (entity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("switched to decrease rank guild staff"), (false));
				if (entity instanceof LivingEntity _entity) {
					ItemStack _setstack = new ItemStack(ChickennuggetacsNonconformistModItems.GUILD_STAFF_RANK_DECREASE);
					_setstack.setCount(1);
					_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
					if (_entity instanceof ServerPlayer _serverPlayer)
						_serverPlayer.getInventory().setChanged();
				}
				entity.getPersistentData().putDouble("scroll", 2);
			}
		}
		if (entity.getPersistentData().getDouble("scroll") == 0) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY)
					.getItem() == ChickennuggetacsNonconformistModItems.GUILD_STAFF) {
				if (entity instanceof Player _player && !_player.level.isClientSide())
					_player.displayClientMessage(new TextComponent("switched to increase rank guild staff"), (false));
				if (entity instanceof LivingEntity _entity) {
					ItemStack _setstack = new ItemStack(ChickennuggetacsNonconformistModItems.GUILD_STAFF_RANK_INCREASE);
					_setstack.setCount(1);
					_entity.setItemInHand(InteractionHand.MAIN_HAND, _setstack);
					if (_entity instanceof ServerPlayer _serverPlayer)
						_serverPlayer.getInventory().setChanged();
				}
				entity.getPersistentData().putDouble("scroll", 1);
			}
		}
		if (entity.getPersistentData().getDouble("scroll") == 4) {
			entity.getPersistentData().putDouble("scroll", 0);
		}
	}
}
