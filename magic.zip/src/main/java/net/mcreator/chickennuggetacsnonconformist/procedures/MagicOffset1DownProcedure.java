package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;

public class MagicOffset1DownProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset - 1;
			entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.CastingOffset = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
	}
}
