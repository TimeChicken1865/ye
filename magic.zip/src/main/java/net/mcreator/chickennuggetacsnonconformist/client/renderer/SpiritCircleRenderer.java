package net.mcreator.chickennuggetacsnonconformist.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.chickennuggetacsnonconformist.entity.SpiritCircleEntity;
import net.mcreator.chickennuggetacsnonconformist.client.model.ModelWindCircle;

public class SpiritCircleRenderer extends MobRenderer<SpiritCircleEntity, ModelWindCircle<SpiritCircleEntity>> {
	public SpiritCircleRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelWindCircle(context.bakeLayer(ModelWindCircle.LAYER_LOCATION)), 0.5f);
		this.addLayer(new EyesLayer<SpiritCircleEntity, ModelWindCircle<SpiritCircleEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("chickennuggetacs_nonconformist:textures/spirit.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(SpiritCircleEntity entity) {
		return new ResourceLocation("chickennuggetacs_nonconformist:textures/invis.png");
	}
}
