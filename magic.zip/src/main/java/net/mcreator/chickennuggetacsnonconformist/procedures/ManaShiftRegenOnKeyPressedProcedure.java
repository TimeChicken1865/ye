package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;
import net.mcreator.chickennuggetacsnonconformist.init.ChickennuggetacsNonconformistModParticles;

public class ManaShiftRegenOnKeyPressedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		{
			double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
					+ (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MaxMana * 0.03;
			entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
				capability.mana = _setval;
				capability.syncPlayerVariables(entity);
			});
		}
		if (world instanceof ServerLevel _level)
			_level.sendParticles(ChickennuggetacsNonconformistModParticles.MANA_PARTICLE, x, y, z, 8, 1, 1, 1, 1);
	}
}
