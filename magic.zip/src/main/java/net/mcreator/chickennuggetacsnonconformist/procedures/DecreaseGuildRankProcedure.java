package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;

public class DecreaseGuildRankProcedure {
	public static void execute(Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).Guild_Rank < (sourceentity
						.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).Guild_Rank) {
			if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).Guild_Rank > 2.5) {
				{
					double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).Guild_Rank - 1;
					entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.Guild_Rank = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
		}
	}
}
