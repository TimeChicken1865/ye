package net.mcreator.chickennuggetacsnonconformist.procedures;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;
import net.mcreator.chickennuggetacsnonconformist.entity.WindEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.WaterEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.SpiritEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.LightningEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.LightEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.FireEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.EarthEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.DarkEntity;
import net.mcreator.chickennuggetacsnonconformist.entity.CastingOffsetEntity;

public class MagicAttack1OnKeyPressedProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 == 1) {
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 30;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 20;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage * 15;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicThickness * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			entity.getPersistentData().putBoolean("lightning", (true));
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset > 0.5) {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							CastingOffsetEntity
									.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
						}
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private LevelAccessor world;

							public void start(LevelAccessor world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
									CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private LevelAccessor world;

									public void start(LevelAccessor world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
											CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
													(float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3),
													0, 0);
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private LevelAccessor world;

											public void start(LevelAccessor world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
													CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(), (float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3), 0, 0);
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private LevelAccessor world;

													public void start(LevelAccessor world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
															CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
																	(float) ((entity.getCapability(
																			ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																			null)
																			.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
																			* 0.3),
																	0, 0);
														}
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, 12);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, 12);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, 12);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, 12);
					} else {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							LightningEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 0.3),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage + 2),
									0);
						}
					}
					entity.getPersistentData().putBoolean("lightning", (false));
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, 20);
		}
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 == 2) {
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 30;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 20;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage * 15;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicThickness * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			entity.getPersistentData().putBoolean("fire", (true));
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset > 0.5) {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							CastingOffsetEntity
									.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
						}
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private LevelAccessor world;

							public void start(LevelAccessor world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
									CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private LevelAccessor world;

									public void start(LevelAccessor world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
											CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
													(float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3),
													0, 0);
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private LevelAccessor world;

											public void start(LevelAccessor world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
													CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(), (float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3), 0, 0);
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private LevelAccessor world;

													public void start(LevelAccessor world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
															CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
																	(float) ((entity.getCapability(
																			ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																			null)
																			.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
																			* 0.3),
																	0, 0);
														}
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, 12);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, 12);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, 12);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, 12);
					} else {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							FireEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 0.3),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage + 3),
									0);
						}
					}
					entity.getPersistentData().putBoolean("fire", (false));
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, 20);
		}
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 == 3) {
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 30;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 20;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage * 15;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicThickness * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			entity.getPersistentData().putBoolean("water", (true));
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset > 0.5) {
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private LevelAccessor world;

							public void start(LevelAccessor world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
									CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private LevelAccessor world;

									public void start(LevelAccessor world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
											CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
													(float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3),
													0, 0);
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private LevelAccessor world;

											public void start(LevelAccessor world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
													CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(), (float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3), 0, 0);
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private LevelAccessor world;

													public void start(LevelAccessor world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
															CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
																	(float) ((entity.getCapability(
																			ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																			null)
																			.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
																			* 0.3),
																	0, 0);
														}
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, 12);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, 12);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, 12);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, 12);
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							CastingOffsetEntity
									.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
						}
					} else {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							WaterEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 0.3),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage + 1),
									0);
						}
					}
					entity.getPersistentData().putBoolean("water", (false));
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, 20);
		}
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 == 4) {
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 30;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 20;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage * 15;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicThickness * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			entity.getPersistentData().putBoolean("wind", (true));
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset > 0.5) {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							CastingOffsetEntity
									.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
						}
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private LevelAccessor world;

							public void start(LevelAccessor world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
									CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private LevelAccessor world;

									public void start(LevelAccessor world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
											CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
													(float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3),
													0, 0);
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private LevelAccessor world;

											public void start(LevelAccessor world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
													CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(), (float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3), 0, 0);
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private LevelAccessor world;

													public void start(LevelAccessor world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
															CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
																	(float) ((entity.getCapability(
																			ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																			null)
																			.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
																			* 0.3),
																	0, 0);
														}
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, 12);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, 12);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, 12);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, 12);
					} else {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							WindEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 0.3),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage + 1),
									0);
						}
					}
					entity.getPersistentData().putBoolean("wind", (false));
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, 20);
		}
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 == 5) {
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 30;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 20;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage * 15;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicThickness * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			entity.getPersistentData().putBoolean("earth", (true));
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset > 0.5) {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							CastingOffsetEntity
									.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
						}
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private LevelAccessor world;

							public void start(LevelAccessor world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
									CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private LevelAccessor world;

									public void start(LevelAccessor world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
											CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
													(float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3),
													0, 0);
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private LevelAccessor world;

											public void start(LevelAccessor world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
													CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(), (float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3), 0, 0);
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private LevelAccessor world;

													public void start(LevelAccessor world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
															CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
																	(float) ((entity.getCapability(
																			ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																			null)
																			.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
																			* 0.3),
																	0, 0);
														}
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, 12);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, 12);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, 12);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, 12);
					} else {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							EarthEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 0.3),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage + 1),
									0);
						}
					}
					entity.getPersistentData().putBoolean("earth", (false));
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, 20);
		}
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 == 6) {
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 30;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 20;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage * 15;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicThickness * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			entity.getPersistentData().putBoolean("dark", (true));
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset > 0.5) {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							CastingOffsetEntity
									.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
						}
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private LevelAccessor world;

							public void start(LevelAccessor world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
									CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private LevelAccessor world;

									public void start(LevelAccessor world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
											CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
													(float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3),
													0, 0);
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private LevelAccessor world;

											public void start(LevelAccessor world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
													CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(), (float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3), 0, 0);
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private LevelAccessor world;

													public void start(LevelAccessor world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
															CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
																	(float) ((entity.getCapability(
																			ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																			null)
																			.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
																			* 0.3),
																	0, 0);
														}
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, 12);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, 12);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, 12);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, 12);
					} else {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							DarkEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 0.3),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage + 4),
									0);
						}
					}
					entity.getPersistentData().putBoolean("dark", (false));
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, 20);
		}
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 == 7) {
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 30;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 20;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage * 15;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicThickness * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			entity.getPersistentData().putBoolean("light", (true));
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset > 0.5) {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							CastingOffsetEntity
									.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
						}
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private LevelAccessor world;

							public void start(LevelAccessor world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
									CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private LevelAccessor world;

									public void start(LevelAccessor world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
											CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
													(float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3),
													0, 0);
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private LevelAccessor world;

											public void start(LevelAccessor world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
													CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(), (float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3), 0, 0);
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private LevelAccessor world;

													public void start(LevelAccessor world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
															CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
																	(float) ((entity.getCapability(
																			ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																			null)
																			.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
																			* 0.3),
																	0, 0);
														}
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, 12);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, 12);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, 12);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, 12);
					} else {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							LightEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 0.3),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage + 4),
									0);
						}
					}
					entity.getPersistentData().putBoolean("light", (false));
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, 20);
		}
		if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicType1 == 8) {
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 30;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 20;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage * 15;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicThickness * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			{
				double _setval = (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).mana
						- (entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
								.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicLength * 35;
				entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
					capability.mana = _setval;
					capability.syncPlayerVariables(entity);
				});
			}
			entity.getPersistentData().putBoolean("spirit", (true));
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset > 0.5) {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							CastingOffsetEntity
									.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
						}
						new Object() {
							private int ticks = 0;
							private float waitTicks;
							private LevelAccessor world;

							public void start(LevelAccessor world, int waitTicks) {
								this.waitTicks = waitTicks;
								MinecraftForge.EVENT_BUS.register(this);
								this.world = world;
							}

							@SubscribeEvent
							public void tick(TickEvent.ServerTickEvent event) {
								if (event.phase == TickEvent.Phase.END) {
									this.ticks += 1;
									if (this.ticks >= this.waitTicks)
										run();
								}
							}

							private void run() {
								if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
									CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
											(float) ((entity
													.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
													.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset * 0.3),
											0, 0);
								}
								new Object() {
									private int ticks = 0;
									private float waitTicks;
									private LevelAccessor world;

									public void start(LevelAccessor world, int waitTicks) {
										this.waitTicks = waitTicks;
										MinecraftForge.EVENT_BUS.register(this);
										this.world = world;
									}

									@SubscribeEvent
									public void tick(TickEvent.ServerTickEvent event) {
										if (event.phase == TickEvent.Phase.END) {
											this.ticks += 1;
											if (this.ticks >= this.waitTicks)
												run();
										}
									}

									private void run() {
										if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
											CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
													(float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3),
													0, 0);
										}
										new Object() {
											private int ticks = 0;
											private float waitTicks;
											private LevelAccessor world;

											public void start(LevelAccessor world, int waitTicks) {
												this.waitTicks = waitTicks;
												MinecraftForge.EVENT_BUS.register(this);
												this.world = world;
											}

											@SubscribeEvent
											public void tick(TickEvent.ServerTickEvent event) {
												if (event.phase == TickEvent.Phase.END) {
													this.ticks += 1;
													if (this.ticks >= this.waitTicks)
														run();
												}
											}

											private void run() {
												if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
													CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(), (float) ((entity
															.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																	null)
															.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
															* 0.3), 0, 0);
												}
												new Object() {
													private int ticks = 0;
													private float waitTicks;
													private LevelAccessor world;

													public void start(LevelAccessor world, int waitTicks) {
														this.waitTicks = waitTicks;
														MinecraftForge.EVENT_BUS.register(this);
														this.world = world;
													}

													@SubscribeEvent
													public void tick(TickEvent.ServerTickEvent event) {
														if (event.phase == TickEvent.Phase.END) {
															this.ticks += 1;
															if (this.ticks >= this.waitTicks)
																run();
														}
													}

													private void run() {
														if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
															CastingOffsetEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
																	(float) ((entity.getCapability(
																			ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY,
																			null)
																			.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).CastingOffset
																			* 0.3),
																	0, 0);
														}
														MinecraftForge.EVENT_BUS.unregister(this);
													}
												}.start(world, 12);
												MinecraftForge.EVENT_BUS.unregister(this);
											}
										}.start(world, 12);
										MinecraftForge.EVENT_BUS.unregister(this);
									}
								}.start(world, 12);
								MinecraftForge.EVENT_BUS.unregister(this);
							}
						}.start(world, 12);
					} else {
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							SpiritEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicSpeed * 0.3),
									(float) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).MagicDamage + 4),
									0);
						}
					}
					entity.getPersistentData().putBoolean("spirit", (false));
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, 20);
		}
	}
}
