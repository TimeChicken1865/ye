package net.mcreator.chickennuggetacsnonconformist.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

// Made with Blockbench 4.1.1
// Exported for Minecraft version 1.17 with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelroar<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("chickennuggetacs_nonconformist", "modelroar"), "main");
	public final ModelPart head;

	public Modelroar(ModelPart root) {
		this.head = root.getChild("head");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition head = partdefinition.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(0, 0).addBox(-9.0F, -11.1923F, 4.5069F, 18.0F, 18.0F, 18.0F, new CubeDeformation(0.0F))
						.texOffs(0, 36).addBox(-8.0F, -5.4683F, -4.6831F, 16.0F, 10.0F, 18.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.552F, 7.4415F, 1.2656F, -0.0873F, 1.5272F, 1.5708F));
		PartDefinition head_r1 = head.addOrReplaceChild("head_r1",
				CubeListBuilder.create().texOffs(57, 53).addBox(-9.0F, -3.5F, -10.5F, 18.0F, 7.0F, 13.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 4.0317F, -5.1831F, 0.6981F, 0.0F, 0.0F));
		PartDefinition head_r2 = head.addOrReplaceChild("head_r2",
				CubeListBuilder.create().texOffs(57, 53).addBox(-9.0F, -3.5F, -10.5F, 18.0F, 7.0F, 12.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -2.9683F, -5.1831F, -0.2182F, 0.0F, 0.0F));
		PartDefinition cube_r5 = head.addOrReplaceChild("cube_r5", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-0.552F, -4.6043F, 14.4909F, -0.6981F, 0.0F, 0.0F));
		PartDefinition cube_r7_r1 = cube_r5.addOrReplaceChild("cube_r7_r1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-6.112F, -12.0676F, 2.2089F, -0.3927F, 0.0F, -0.4363F));
		PartDefinition cube_r7_r2_r1 = cube_r7_r1.addOrReplaceChild("cube_r7_r2_r1",
				CubeListBuilder.create().texOffs(12, 90).addBox(-1.5F, -10.0F, 4.5F, 3.0F, 20.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.7212F, -19.3136F, 3.8776F, -0.5672F, 0.5236F, 0.0F));
		PartDefinition cube_r7_r1_r1 = cube_r7_r1.addOrReplaceChild("cube_r7_r1_r1",
				CubeListBuilder.create().texOffs(62, 78).addBox(-4.6304F, -9.8136F, 0.7475F, 5.0F, 22.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.5F, 0.5F, 0.0F, 0.0F, 0.5236F, 0.0F));
		PartDefinition cube_r7_r2 = cube_r5.addOrReplaceChild("cube_r7_r2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-9.112F, -5.9391F, 7.351F, -0.3927F, 0.0F, -1.2217F));
		PartDefinition cube_r7_r3_r1 = cube_r7_r2.addOrReplaceChild("cube_r7_r3_r1",
				CubeListBuilder.create().texOffs(92, 0).addBox(-1.5F, -10.0F, 8.5F, 3.0F, 18.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.7212F, -19.3136F, 3.8776F, -0.829F, 0.5236F, 0.0F));
		PartDefinition cube_r7_r2_r2 = cube_r7_r2.addOrReplaceChild("cube_r7_r2_r2",
				CubeListBuilder.create().texOffs(72, 0).addBox(-4.6304F, -9.8136F, 0.7475F, 5.0F, 22.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.5F, 0.5F, 0.0F, -0.2618F, 0.5236F, 0.0F));
		PartDefinition cube_r7_r3 = cube_r5.addOrReplaceChild("cube_r7_r3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(9.112F, -5.9391F, 7.351F, -0.3927F, 0.0F, 1.2217F));
		PartDefinition cube_r7_r4_r1 = cube_r7_r3.addOrReplaceChild("cube_r7_r4_r1",
				CubeListBuilder.create().texOffs(24, 91).addBox(-1.5F, -10.0F, 8.5F, 3.0F, 18.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.7212F, -19.3136F, 3.8776F, -0.829F, -0.5236F, 0.0F));
		PartDefinition cube_r7_r3_r2 = cube_r7_r3.addOrReplaceChild("cube_r7_r3_r2",
				CubeListBuilder.create().texOffs(22, 64).addBox(-0.3696F, -9.8136F, 0.7475F, 5.0F, 22.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.5F, 0.5F, 0.0F, -0.2618F, -0.5236F, 0.0F));
		PartDefinition cube_r6_r1 = cube_r5.addOrReplaceChild("cube_r6_r1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(5.888F, -12.0676F, 2.2089F, -0.3927F, 0.0F, 0.48F));
		PartDefinition cube_r6_r2_r1 = cube_r6_r1.addOrReplaceChild("cube_r6_r2_r1",
				CubeListBuilder.create().texOffs(0, 90).addBox(-1.5F, -9.0F, 5.0F, 3.0F, 20.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.6983F, -20.7812F, 3.6839F, -0.5672F, -0.5236F, 0.0F));
		PartDefinition cube_r6_r1_r1 = cube_r6_r1.addOrReplaceChild("cube_r6_r1_r1",
				CubeListBuilder.create().texOffs(42, 73).addBox(0.3797F, -10.2812F, 0.0912F, 5.0F, 22.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.5F, 0.5F, 0.0F, 0.0F, -0.5236F, 0.0F));
		PartDefinition cube_r5_r1 = cube_r5.addOrReplaceChild("cube_r5_r1",
				CubeListBuilder.create().texOffs(0, 64).addBox(-2.75F, -12.0F, 1.0F, 6.0F, 21.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.362F, -11.4472F, -0.2129F, -0.3927F, 0.0F, 0.0F));
		PartDefinition cube_r5_r2_r1 = cube_r5_r1.addOrReplaceChild("cube_r5_r2_r1",
				CubeListBuilder.create().texOffs(82, 78).addBox(-2.0F, -14.0F, 3.0F, 4.0F, 24.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.25F, -22.0F, 3.5F, -0.4363F, 0.0F, 0.0F));
		PartDefinition horn = head.addOrReplaceChild("horn",
				CubeListBuilder.create().texOffs(72, 27).addBox(-3.0F, -10.3078F, 0.5098F, 6.0F, 7.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-11.0F, 11.1155F, 11.9971F, -0.3927F, 0.2618F, 0.5236F));
		PartDefinition head_r3 = horn.addOrReplaceChild("head_r3",
				CubeListBuilder.create().texOffs(54, 9).addBox(-1.0F, -3.5F, -3.5F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 6.6156F, -2.5196F, -1.309F, 0.0F, 0.0F));
		PartDefinition head_r4 = horn.addOrReplaceChild("head_r4",
				CubeListBuilder.create().texOffs(0, 36).addBox(-2.0F, -6.0F, -5.0F, 4.0F, 11.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.6922F, 4.5098F, -0.48F, 0.0F, 0.0F));
		PartDefinition horn2 = head.addOrReplaceChild("horn2",
				CubeListBuilder.create().texOffs(50, 36).addBox(-3.0F, -10.3078F, 0.5098F, 6.0F, 7.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(11.0F, 11.1155F, 11.9971F, -0.3927F, -0.2618F, -0.5236F));
		PartDefinition head_r5 = horn2.addOrReplaceChild("head_r5",
				CubeListBuilder.create().texOffs(54, 0).addBox(-1.0F, -3.5F, -3.5F, 2.0F, 7.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 6.6156F, -2.5196F, -1.309F, 0.0F, 0.0F));
		PartDefinition head_r6 = horn2.addOrReplaceChild("head_r6",
				CubeListBuilder.create().texOffs(0, 0).addBox(-2.0F, -6.0F, -5.0F, 4.0F, 11.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.6922F, 4.5098F, -0.48F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue,
			float alpha) {
		head.render(poseStack, buffer, packedLight, packedOverlay);
	}
}
