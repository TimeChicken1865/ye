
package net.mcreator.chickennuggetacsnonconformist.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.Minecraft;

import net.mcreator.chickennuggetacsnonconformist.world.inventory.GuildGUIMenu;
import net.mcreator.chickennuggetacsnonconformist.procedures.GuildStartPowerProcedure;
import net.mcreator.chickennuggetacsnonconformist.procedures.GuildStaffOfficerRankUsageProcedure;
import net.mcreator.chickennuggetacsnonconformist.network.GuildGUIButtonMessage;
import net.mcreator.chickennuggetacsnonconformist.network.ChickennuggetacsNonconformistModVariables;
import net.mcreator.chickennuggetacsnonconformist.ChickennuggetacsNonconformistMod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.systems.RenderSystem;

public class GuildGUIScreen extends AbstractContainerScreen<GuildGUIMenu> {
	private final Level world;
	private final int x, y, z;
	private final Player entity;

	public GuildGUIScreen(GuildGUIMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 0;
		this.imageHeight = 0;
	}

	private static final ResourceLocation texture = new ResourceLocation("chickennuggetacs_nonconformist:textures/guild_gui.png");

	@Override
	public void render(PoseStack ms, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(ms);
		super.render(ms, mouseX, mouseY, partialTicks);
		this.renderTooltip(ms, mouseX, mouseY);
	}

	@Override
	protected void renderBg(PoseStack ms, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShaderTexture(0, texture);
		this.blit(ms, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight, this.imageWidth, this.imageHeight);
		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	public void containerTick() {
		super.containerTick();
	}

	@Override
	protected void renderLabels(PoseStack poseStack, int mouseX, int mouseY) {
		this.font.draw(poseStack, "Guild rank 2 = member", -203, -79, -16711936);
		this.font.draw(poseStack, "Guild rank 3 = officer", -203, -61, -13369600);
		this.font.draw(poseStack, "Guild rank 4 = co owner", -204, -41, -13369600);
		this.font.draw(poseStack, "Guild rank 1 = you have no friends", -203, -99, -16711936);
		this.font.draw(poseStack, "Guild rank 5 = Guild leader", -205, -23, -13369600);
		this.font.draw(poseStack, "" + (int) ((entity.getCapability(ChickennuggetacsNonconformistModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new ChickennuggetacsNonconformistModVariables.PlayerVariables())).Guild_Rank) + "", -149, 8, -13369600);
		this.font.draw(poseStack, "Guild rank:", -210, 7, -16711936);
		this.font.draw(poseStack, "*Only officers and Co owners can invite or ban people for the guild*", -167, 93, -65536);
	}

	@Override
	public void onClose() {
		super.onClose();
		Minecraft.getInstance().keyboardHandler.setSendRepeatsToGui(false);
	}

	@Override
	public void init() {
		super.init();
		this.minecraft.keyboardHandler.setSendRepeatsToGui(true);
		this.addRenderableWidget(new Button(this.leftPos + -54, this.topPos + -11, 119, 20, new TextComponent("Summon guild staff"), e -> {
			if (GuildStartPowerProcedure.execute(entity)) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new GuildGUIButtonMessage(0, x, y, z));
				GuildGUIButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}) {
			@Override
			public void render(PoseStack ms, int gx, int gy, float ticks) {
				if (GuildStartPowerProcedure.execute(entity))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addRenderableWidget(new Button(this.leftPos + -54, this.topPos + 12, 119, 20, new TextComponent("Summon guild staff"), e -> {
			if (GuildStaffOfficerRankUsageProcedure.execute(entity)) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new GuildGUIButtonMessage(1, x, y, z));
				GuildGUIButtonMessage.handleButtonAction(entity, 1, x, y, z);
			}
		}) {
			@Override
			public void render(PoseStack ms, int gx, int gy, float ticks) {
				if (GuildStaffOfficerRankUsageProcedure.execute(entity))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addRenderableWidget(new Button(this.leftPos + -55, this.topPos + 35, 119, 20, new TextComponent("Banish guild staff"), e -> {
			if (GuildStaffOfficerRankUsageProcedure.execute(entity)) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new GuildGUIButtonMessage(2, x, y, z));
				GuildGUIButtonMessage.handleButtonAction(entity, 2, x, y, z);
			}
		}) {
			@Override
			public void render(PoseStack ms, int gx, int gy, float ticks) {
				if (GuildStaffOfficerRankUsageProcedure.execute(entity))
					super.render(ms, gx, gy, ticks);
			}
		});
		this.addRenderableWidget(new Button(this.leftPos + -205, this.topPos + -122, 46, 20, new TextComponent("Back"), e -> {
			if (true) {
				ChickennuggetacsNonconformistMod.PACKET_HANDLER.sendToServer(new GuildGUIButtonMessage(3, x, y, z));
				GuildGUIButtonMessage.handleButtonAction(entity, 3, x, y, z);
			}
		}));
	}
}
